# 英文 PDF 学习助手 (pdf-study-assistant)

一个基于 Streamlit 的交互式应用，帮助你快速理解英文 PDF 课程资料：支持逐页即时翻译、要点总结、通俗解释、概念符号说明与延伸建议。内置缓存，避免重复调用大模型；支持 OCR 回退处理扫描件。

## 核心功能
- 上传 PDF 文件（仅支持 PDF）
- 页面缩略图导航 + 当前页大图预览
- 点击页面或缩略图后自动抽取该页文本并调用大模型（Gemini 2.5 Pro 或企业内部网关）
- 五段结构化输出：中文翻译 / 核心要点 / 通俗解释 / 概念与符号说明 / 如需延伸
- 可调参数：翻译风格(直译|意译)、技术深度(入门|标准|进阶)、术语表（保证一致性）
- 缓存：同一文件同一页同一参数组合不重复请求
- OCR：若页面无文字层或文本过少自动触发 pytesseract
- 整份文档一键总结（可选）

## 环境要求
- Python 3.10+
- Windows 需安装 Tesseract OCR：
  1. 下载安装包：https://github.com/UB-Mannheim/tesseract/wiki
  2. 安装后将路径（例如 `C:\Program Files\Tesseract-OCR`）加入系统环境变量 PATH

## 安装依赖
```powershell
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
```

## 运行应用
```powershell
streamlit run app.py
```

## 配置环境变量
复制 `.env.example` 为 `.env` 并填写：
```
GOOGLE_API_KEY=你的API密钥
MODEL_NAME=gemini-2.5-pro
ENTERPRISE_GATEWAY_URL=可选的企业网关URL
ENTERPRISE_GATEWAY_KEY=企业网关鉴权密钥(可选)
 OPENAI_API_KEY=可选的OpenAI Key
 OPENAI_MODEL_NAME=gpt-4o-mini
```
优先级：企业网关 > Gemini > OpenAI。若仅提供 OpenAI Key 将自动走 OpenAI Provider。

## 术语表使用示例
在侧边栏术语表文本区输入：
```
learning rate=学习率
batch normalization=批归一化
cross entropy=交叉熵
```
将确保翻译时这些术语一致。

## 项目结构
```
app.py                # Streamlit 主入口
src/config.py         # 环境与应用配置
src/prompts.py        # Prompt 模板与构建
src/services/llm_client.py  # LLM 抽象与 Gemini 接入
src/utils/pdf_utils.py # PDF 解析、渲染、OCR
src/utils/cache_utils.py # 缓存封装
requirements.txt
README.md
.env.example
.tests/test_pdf_utils.py # 基础测试
```

## 后续扩展建议
- 多模型策略：fallback / ensemble
- 页面内公式识别（MathOCR）
- 术语自动抽取与知识图谱
- 向量数据库做跨页语义搜索

## 许可证
本项目示例代码仅用于学习与内部 PoC，可自行选择开源协议。
