import streamlit as st

# 直接跳转到上传页面
st.switch_page("pages/01_上传与配置.py")
